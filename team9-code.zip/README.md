# comp0010-team9
Coursework for UCL COMP0010

## Naming Conventions
* this-is-a-directory
* ThisIsJavaClass.java
* ThisIsInterface
* thisIsMethod
* thisIsVariable
* THIS_IS_CONSTANT

## PS
WATCH SHOUJOKAGEKI:sparkles::crown::banana:
