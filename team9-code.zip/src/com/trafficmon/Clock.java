package com.trafficmon;

import java.time.LocalTime;

public interface Clock {
    LocalTime getCurrentTime();
}
