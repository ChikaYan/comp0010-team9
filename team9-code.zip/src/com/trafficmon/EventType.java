package com.trafficmon;

public enum EventType {
    ENTRY,
    EXIT
}
